const express = require("express");
const Question = require("../models/Question");
const auth = require("../middleware/auth");

const router = express.Router();

// Gauti visus klausimus
router.get("/", async (req, res) => {
  const questions = await Question.find().sort({ date: -1 });
  res.json(questions);
});

// Pridėti klausimą
router.post("/", auth, async (req, res) => {
  const { question_text } = req.body;

  const question = await Question.create({
    question_text,
    user_id: req.userId,
  });

  res.json(question);
});

module.exports = router;
