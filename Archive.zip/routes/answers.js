const express = require("express");
const Answer = require("../models/Answer");
const auth = require("../middleware/auth");

const router = express.Router();

// Gauti atsakymus konkrečiam klausimui
router.get("/:questionId/answers", async (req, res) => {
  const answers = await Answer.find({
    question_id: req.params.questionId,
  }).sort({ date: -1 });
  res.json(answers);
});

// Pridėti atsakymą prie klausimo
router.post("/:questionId/answer", auth, async (req, res) => {
  const { text } = req.body;

  const answer = await Answer.create({
    text,
    question_id: req.params.questionId,
    user_id: req.userId,
  });

  res.json(answer);
});

module.exports = router;
