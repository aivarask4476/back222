const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/forum";
mongoose.connect(MONGO_URI);

// Naudojam atskirtus maršrutus
app.use("/auth", require("./routes/auth"));
app.use("/questions", require("./routes/questions"));
app.use("/question", require("./routes/answers")); // su :id

const PORT = process.env.PORT || 4000;
app.listen(PORT, () =>
  console.log(`✅ Serveris veikia http://localhost:${PORT}`)
);
