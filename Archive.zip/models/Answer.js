const mongoose = require("mongoose");

const AnswerSchema = new mongoose.Schema({
  text: String,
  date: { type: Date, default: Date.now },
  question_id: mongoose.Schema.Types.ObjectId,
  user_id: mongoose.Schema.Types.ObjectId,
});

module.exports = mongoose.model("Answer", AnswerSchema);
