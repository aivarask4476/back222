const mongoose = require("mongoose");

const QuestionSchema = new mongoose.Schema({
  question_text: String,
  date: { type: Date, default: Date.now },
  user_id: mongoose.Schema.Types.ObjectId,
});

module.exports = mongoose.model("Question", QuestionSchema);
